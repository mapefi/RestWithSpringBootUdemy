INSERT INTO person VALUES (1,'Uberlândia - Minas Gerais - Brasil','Leandro','Male','Costa');
INSERT INTO person VALUES (2,'Uberlândia - Minas Gerais - Brasil','Gabriela','Female','Costa');
INSERT INTO person VALUES (5,'Patos de Minas - Minas Gerais - Brasil','Flávio','Male','Costa');
INSERT INTO person VALUES (6,'Uberlândia - Minas Gerais - Brasil','Gabriela','Female','Costa');
INSERT INTO person VALUES (7,'Uberlândia - Minas Gerais - Brasil','Fernanda','Female','Cardoso da Silva');
INSERT INTO person VALUES (8,'Uberlândia - Minas Gerais - Brasil','Pedro','Female','Costa');
